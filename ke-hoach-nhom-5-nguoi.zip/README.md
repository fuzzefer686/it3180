# Về Cùng — khung web ghép xe sinh viên

React + TypeScript + Firebase, dành cho nhóm 5 sinh viên HUST. **Đây là scaffold**, chưa có đặt chuyến, bản đồ VietMap hoặc thanh toán. Bộ [kế hoạch](ke-hoach/README.md) vẫn giữ trong repo.

## Chạy local

Cần Node **22** (từ 22.12), npm và Java **21**. Nếu dùng nvm: `nvm install` rồi `nvm use`. Mọi người chạy từ root repo.

```bash
npm ci
npm run dev
```

- Web: http://127.0.0.1:5173
- Emulator UI: http://127.0.0.1:4000
- Auth 9099, Firestore 8080, Functions 5001. Chờ Functions báo khởi tạo xong.
- Terminal thứ hai: `npm run seed:local`, sau đó bấm **Kiểm tra Firebase** và thử **User mẫu → Đọc hồ sơ qua Functions** trên trang tổng quan.
- Không cần tài khoản Firebase, key thật hoặc billing để chạy Emulator. Lần đầu CLI cần internet tải emulator. Dữ liệu local mất khi dừng; chạy lại seed.
- Không cần tạo `.env.local` cho local mặc định. Mẫu cấu hình ở `web/.env.example`; nếu có config local, giữ project `demo-vecung` và `VITE_USE_EMULATORS=true`.

Seed chỉ chạy localhost, tạo `user@student.example`, `driver@student.example`, `admin@student.example`, mật khẩu `DemoOnly!2026`. Đây là tài khoản hư cấu của Emulator, không dùng trên cloud. Chưa có điểm hoặc ví thực hiện nghiệp vụ.

## Kiểm tra

```bash
npm run typecheck
npm run build
npm test
npm run test:integration
# Hoặc toàn bộ:
npm run check
```

Dừng `npm run dev` trước test integration/check vì Emulator test dùng cùng port. Tests chứng minh callable đọc DB, token uid, phân quyền, khóa user hiện tại và Rules chặn client. Test chỉ dùng Emulator, không VietMap/cloud. `npm run preview` phục vụ bản build web; để kiểm tra backend vẫn cần `npm run emulators`.

## Cấu trúc và phân công

| Người | Frontend | Backend / phần chung |
|---|---|---|
| 1 — Lead | App/layout, components, lib | Foundation, shared, scripts, config, CI |
| 2 | web/src/modules/auth | functions/src/modules/auth |
| 3 | web/src/modules/trips | functions/src/modules/trips |
| 4 | web/src/modules/bookings | functions/src/modules/bookings |
| 5 | web/src/modules/wallets | functions/src/modules/wallets |

- `shared/contracts.ts`: types/schema chung; báo lead trước khi đổi.
- `functions/src/index.ts`: nơi đăng ký/export callable; handler nằm riêng từng module.
- `functions/lib/`: code build gồm Functions và shared contract; Firebase deploy lấy main `lib/functions/src/index.js`. Không commit build output.
- `tests/unit`, `tests/integration`: test nghiệp vụ/luồng/permission của các owner.
- `docs/contracts.md`: API nền và hướng dẫn thêm chức năng.
- Firestore Rules chặn client; FE đọc/ghi nghiệp vụ qua Functions. Đây là lựa chọn kiến trúc V1, chưa dùng realtime listeners.

## Làm việc trên GitHub

Remote hiện có `dev`, `staging`, `main`; dùng **dev**, không develop. Local hiện bắt đầu từ `master`; scaffold chưa commit/push. Local master có lịch sử riêng với origin/main. Cách đơn giản để bàn giao: clone remote vào thư mục mới, tạo feature branch từ origin/dev, copy scaffold sang (bỏ .git, node_modules, build output và .env), kiểm tra rồi mở PR vào dev. Không force push hoặc ghép lịch sử khác nhau chỉ để đưa baseline lên.

Mỗi task: lấy dev mới → tạo feature branch → code/test → push feature → PR base dev → reviewer → lead merge. Bản ổn: PR dev → staging, test chung; PR staging → main. Không copy code của nhau hoặc push thẳng nhánh môi trường. Xem [workflow](ke-hoach/08-github-workflow.md).

CI job **checks** chạy trên PR/push dev/staging/main (master hỗ trợ baseline hiện tại). Sau khi CI chạy lần đầu, chọn checks làm required status check cho ba nhánh.

## Cloud và deploy — chưa bật

Cloud Functions cần **Blaze + billing**, không bảo đảm free hoàn toàn. Hiện chưa tạo/cấu hình project cloud hoặc deploy. Firebase Hosting dùng domain `<project-id>.web.app`.

Pipeline deploy mặc định bị tắt. Khi lead quyết định triển khai:

1. Tạo 3 Firebase projects và GitHub Environments: dev, staging, production-demo. Bật email/password Auth, Firestore và billing cho từng project; cùng Functions region asia-southeast1.
2. Mỗi GitHub Environment cấu hình Variables: FIREBASE_PROJECT_ID, FIREBASE_API_KEY, FIREBASE_AUTH_DOMAIN, FIREBASE_APP_ID, WIF_PROVIDER, DEPLOY_SERVICE_ACCOUNT. Web config không phải private credential; vẫn phải giữ quyền backend/Rules.
3. Cấu hình Google Workload Identity Federation, giới hạn trust theo repo/nhánh/environment và quyền deploy cần thiết. Không lưu service-account private key trong repo. CI checks không cần Google credentials.
4. Đặt budget/usage controls; rồi mới bật repository variable ENABLE_FIREBASE_DEPLOY=true. Test dev trước khi phát hành staging/main. Xem [hosting](ke-hoach/06-hosting-cicd.md).

CI build web đúng Firebase project cloud, kiểm tra config trước deploy, dùng ADC và deploy Functions/Rules/indexes/Hosting. Workflow chưa được thử trên account cloud. Kiểm tra index readiness và smoke test sau release; rollback code không rollback dữ liệu.

Không dùng `firebase init` để ghi đè scaffold. Không seed admin mẫu lên cloud. VietMap map client key do người 3 bổ sung; VietMap REST key giữ backend/Secret Manager. Điểm demo không có giá trị tiền.

Kết quả kiểm chứng và giới hạn dependency xem [báo cáo](docs/validation.md).

## Việc của lead

Đọc [checklist lead](ke-hoach/09-checklist-lead.md) và [tech stack](ke-hoach/07-tech-stack.md). Đầu tiên cho cả 5 người chạy cùng scaffold thành công; sau đó giao task nhỏ và chốt contract trước khi code.
